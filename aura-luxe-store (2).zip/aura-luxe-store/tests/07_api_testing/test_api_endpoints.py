"""
API Testing Suite
Uses pytest and requests to comprehensively validate all backend REST endpoints.
Includes exhaustive positive (valid) and negative (invalid / error handling) test cases:
- /api/health
- /api/products (queries: category, search, max_price, sort)
- /api/products/{id} (valid ID vs 404 invalid ID)
- /api/coupons/verify (valid AURA10 vs invalid coupon)
- /api/cart/validate (calculation vs bad payload)
- /api/orders (creation 201 vs missing fields / invalid email 400)
- /api/orders/{id} (retrieval vs 404)
- /api/newsletter (valid email vs malformed email)
- /api/contact (valid submission vs missing fields)
"""

import pytest
import requests


def test_api_health_check(live_server):
    """GET /api/health returns 200 and healthy status."""
    res = requests.get(f"{live_server}/api/health")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "healthy"
    assert data["service"] == "Aura Luxe Store API"
    assert "version" in data
    assert data["productsCount"] == 14


def test_api_get_all_products(live_server):
    """GET /api/products returns all 14 catalogue products."""
    res = requests.get(f"{live_server}/api/products")
    assert res.status_code == 200
    data = res.json()
    assert data["success"] is True
    assert data["count"] == 14
    assert len(data["products"]) == 14


def test_api_filter_products_by_category(live_server):
    """GET /api/products?category=Clothing returns only clothing products."""
    res = requests.get(f"{live_server}/api/products?category=Clothing")
    assert res.status_code == 200
    data = res.json()
    assert data["count"] == 3
    for p in data["products"]:
        assert p["category"] == "Clothing"


def test_api_filter_products_by_search(live_server):
    """GET /api/products?search=trench returns matching products."""
    res = requests.get(f"{live_server}/api/products?search=trench")
    assert res.status_code == 200
    data = res.json()
    assert data["count"] >= 1
    assert any("trench" in p["name"].lower() for p in data["products"])


def test_api_filter_products_by_price(live_server):
    """GET /api/products?max_price=100 returns only items <= $100."""
    res = requests.get(f"{live_server}/api/products?max_price=100")
    assert res.status_code == 200
    data = res.json()
    for p in data["products"]:
        assert p["discountPrice"] <= 100.0


def test_api_sort_products_low_to_high(live_server):
    """GET /api/products?sort=low-high returns products in ascending price order."""
    res = requests.get(f"{live_server}/api/products?sort=low-high")
    assert res.status_code == 200
    prices = [p["discountPrice"] for p in res.json()["products"]]
    assert prices == sorted(prices)


def test_api_get_single_product_valid(live_server):
    """GET /api/products/1 returns valid details for Silk Cashmere Trench Coat."""
    res = requests.get(f"{live_server}/api/products/1")
    assert res.status_code == 200
    data = res.json()
    assert data["success"] is True
    assert data["product"]["id"] == 1
    assert data["product"]["name"] == "Silk Cashmere Trench Coat"


def test_api_get_single_product_invalid_not_found(live_server):
    """GET /api/products/9999 returns HTTP 404 Not Found."""
    res = requests.get(f"{live_server}/api/products/9999")
    assert res.status_code == 404
    data = res.json()
    assert data["success"] is False
    assert "not found" in data["error"].lower()


def test_api_verify_coupon_valid(live_server):
    """POST /api/coupons/verify with valid 'AURA10' returns 10% discount."""
    res = requests.post(f"{live_server}/api/coupons/verify", json={"code": "AURA10"})
    assert res.status_code == 200
    data = res.json()
    assert data["valid"] is True
    assert data["discountPercent"] == 10


def test_api_verify_coupon_invalid(live_server):
    """POST /api/coupons/verify with bogus coupon returns HTTP 400."""
    res = requests.post(f"{live_server}/api/coupons/verify", json={"code": "FAKECODE999"})
    assert res.status_code == 400
    data = res.json()
    assert data["valid"] is False
    assert "invalid" in data["error"].lower()


def test_api_verify_coupon_empty_payload(live_server):
    """POST /api/coupons/verify with empty payload returns HTTP 400."""
    res = requests.post(f"{live_server}/api/coupons/verify", json={})
    assert res.status_code == 400


def test_api_validate_cart_success(live_server):
    """POST /api/cart/validate accurately calculates subtotal, discounts, and shipping."""
    payload = {
        "items": [
            {"productId": 1, "quantity": 1, "color": "Camel", "size": "M"}  # $199.00
        ],
        "coupon": "AURA10"
    }
    res = requests.post(f"{live_server}/api/cart/validate", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert data["subtotal"] == 199.00
    assert data["shipping"] == 0.0  # Free shipping over $100
    assert data["discountAmount"] == 19.90  # 10% discount
    assert data["total"] == 179.10


def test_api_validate_cart_invalid_product(live_server):
    """POST /api/cart/validate with non-existent product returns HTTP 400."""
    payload = {
        "items": [{"productId": 9999, "quantity": 1}]
    }
    res = requests.post(f"{live_server}/api/cart/validate", json=payload)
    assert res.status_code == 400


def test_api_create_and_retrieve_order_flow(live_server):
    """POST /api/orders creates a new order (201) and GET /api/orders/{id} retrieves it."""
    order_payload = {
        "firstName": "Camille",
        "lastName": "Laurent",
        "email": "camille.laurent@example.com",
        "phone": "+33 6 12 34 56 78",
        "address": "15 Rue de la Paix",
        "city": "Paris",
        "state": "IDF",
        "zip": "75002",
        "country": "France",
        "paymentMethod": "card",
        "items": [
            {"productId": 7, "quantity": 1, "color": "Noir Gold", "size": "One Size"} # $179.00
        ],
        "coupon": "AURA10"
    }

    # 1. Place Order
    create_res = requests.post(f"{live_server}/api/orders", json=order_payload)
    assert create_res.status_code == 201
    create_data = create_res.json()
    assert create_data["success"] is True
    order_id = create_data["orderId"]
    assert order_id.startswith("AUR-")

    # 2. Retrieve Order
    get_res = requests.get(f"{live_server}/api/orders/{order_id}")
    assert get_res.status_code == 200
    get_data = get_res.json()
    assert get_data["order"]["orderId"] == order_id
    assert get_data["order"]["customer"]["email"] == "camille.laurent@example.com"


def test_api_create_order_missing_required_fields(live_server):
    """POST /api/orders with missing email or address returns HTTP 400."""
    bad_payload = {
        "firstName": "Camille",
        # Missing lastName, email, address, etc.
        "items": [{"productId": 1, "quantity": 1}]
    }
    res = requests.post(f"{live_server}/api/orders", json=bad_payload)
    assert res.status_code == 400
    data = res.json()
    assert data["success"] is False
    assert "missing" in data


def test_api_create_order_empty_cart(live_server):
    """POST /api/orders with empty items list returns HTTP 400."""
    payload = {
        "firstName": "Jane",
        "lastName": "Doe",
        "email": "jane@example.com",
        "phone": "555-1234",
        "address": "123 Main St",
        "city": "NY",
        "zip": "10001",
        "items": []
    }
    res = requests.post(f"{live_server}/api/orders", json=payload)
    assert res.status_code == 400
    assert "empty" in res.json()["error"].lower()


def test_api_get_order_non_existent(live_server):
    """GET /api/orders/AUR-000000 returns HTTP 404."""
    res = requests.get(f"{live_server}/api/orders/AUR-000000")
    assert res.status_code == 404


def test_api_newsletter_subscription_valid_and_invalid(live_server):
    """POST /api/newsletter validates email format."""
    # Valid
    valid_res = requests.post(f"{live_server}/api/newsletter", json={"email": "fashionista@lifestyle.com"})
    assert valid_res.status_code == 200
    assert valid_res.json()["success"] is True

    # Invalid
    invalid_res = requests.post(f"{live_server}/api/newsletter", json={"email": "not-an-email"})
    assert invalid_res.status_code == 400
    assert invalid_res.json()["success"] is False


def test_api_contact_submission_valid_and_invalid(live_server):
    """POST /api/contact handles concierge messages with field validation."""
    # Valid
    valid_payload = {
        "name": "Julian Moore",
        "email": "julian@luxury.com",
        "subject": "Private Showroom Visit",
        "message": "Looking to schedule a VIP showroom viewing next Friday."
    }
    res = requests.post(f"{live_server}/api/contact", json=valid_payload)
    assert res.status_code == 200
    assert res.json()["success"] is True

    # Invalid (missing message)
    invalid_payload = {
        "name": "Julian Moore",
        "email": "julian@luxury.com",
        "subject": "Missing message"
    }
    inv_res = requests.post(f"{live_server}/api/contact", json=invalid_payload)
    assert inv_res.status_code == 400
